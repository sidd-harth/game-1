// const express = require('express');
// const app = express();
// const http = require('http').Server(app);
// const io = require('socket.io')(http);
// const { v4: uuidv4 } = require('uuid');

// app.use(express.static('public'));
// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));

// // Global game state management
// const globalState = {
//     activeGames: new Map(), // Stores all active and completed games
//     currentGame: null,      // Reference to current active game
// };

// // Game class to manage individual game instances
// class Game {
//     constructor() {
//         this.id = uuidv4();
//         this.startTime = new Date();
//         this.endTime = null;
//         this.status = 'waiting'; // waiting, active, completed
//         this.timer = 30;
//         this.interval = null;
//         this.scores = {
//             red: 0,
//             blue: 0
//         };
//         this.players = {
//             red: new Map(),  // Map of player ID to player object for red team
//             blue: new Map()  // Map of player ID to player object for blue team
//         };
//         this.leaderboard = [];
//     }

//     addPlayer(playerId, playerName, team) {
//         const playerObj = {
//             id: playerId,
//             name: playerName,
//             team: team,
//             clicks: 0,
//             joinTime: new Date()
//         };
//         this.players[team].set(playerId, playerObj);
//         return playerObj;
//     }

//     removePlayer(playerId) {
//         for (const team of ['red', 'blue']) {
//             if (this.players[team].has(playerId)) {
//                 this.players[team].delete(playerId);
//                 return true;
//             }
//         }
//         return false;
//     }

//     incrementScore(team) {
//         if (team in this.scores) {
//             this.scores[team]++;
//             return true;
//         }
//         return false;
//     }

//     incrementPlayerClicks(playerId) {
//         for (const team of ['red', 'blue']) {
//             const player = this.players[team].get(playerId);
//             if (player) {
//                 player.clicks++;
//                 return true;
//             }
//         }
//         return false;
//     }

//     getPlayerList() {
//         return {
//             red: Array.from(this.players.red.values()).map(p => p.name),
//             blue: Array.from(this.players.blue.values()).map(p => p.name)
//         };
//     }

//     generateLeaderboard() {
//         const allPlayers = [
//             ...Array.from(this.players.red.values()),
//             ...Array.from(this.players.blue.values())
//         ];
        
//         return allPlayers
//             .map(player => ({
//                 id: player.id,
//                 name: player.name,
//                 team: player.team,
//                 clicks: player.clicks
//             }))
//             .sort((a, b) => b.clicks - a.clicks);
//     }

//     getWinner() {
//         if (this.scores.red > this.scores.blue) return 'Red';
//         if (this.scores.blue > this.scores.red) return 'Blue';
//         return 'Tie';
//     }
// }

// // Game management functions
// function createNewGame() {
//     const game = new Game();
//     globalState.activeGames.set(game.id, game);
//     globalState.currentGame = game;
//     return game;
// }

// function endCurrentGame() {
//     if (globalState.currentGame) {
//         const game = globalState.currentGame;
//         game.status = 'completed';
//         game.endTime = new Date();
//         game.leaderboard = game.generateLeaderboard();
//         clearInterval(game.interval);
//         game.interval = null;
//         return game;
//     }
//     return null;
// }

// // Routes
// app.get('/', (req, res) => {
//     res.sendFile(__dirname + '/public/index.html');
// });

// app.get('/game', (req, res) => {
//     res.sendFile(__dirname + '/public/game.html');
// });

// app.get('/admin', (req, res) => {
//     res.sendFile(__dirname + '/public/admin.html');
// });

// // Socket.IO connection handling
// io.on('connection', (socket) => {
//     // Handle player joining a team
//     socket.on('joinTeam', (data) => {
//         const { name, team } = data;
//         const playerId = uuidv4();
        
//         // Store player info in socket
//         socket.playerId = playerId;
//         socket.playerName = name;
//         socket.team = team;

//         // Add player to current game if it exists
//         if (globalState.currentGame) {
//             // Remove player from any existing team first
//             if (socket.playerId) {
//                 globalState.currentGame.removePlayer(socket.playerId);
//             }
            
//             // Add player to new team
//             globalState.currentGame.addPlayer(playerId, name, team);
            
//             // Broadcast updated player lists
//             io.emit('updatePlayers', globalState.currentGame.getPlayerList());
//         }
//     });

//     // Handle block clicks
//     socket.on('blockClick', (team) => {
//         if (!globalState.currentGame || globalState.currentGame.status !== 'active') return;
//         if (socket.team !== team) return;

//         const game = globalState.currentGame;
//         game.incrementScore(team);
        
//         if (socket.playerId) {
//             game.incrementPlayerClicks(socket.playerId);
//         }

//         // Broadcast updated scores
//         io.emit('updateCounts', {
//             red: game.scores.red,
//             blue: game.scores.blue,
//             playerClicks: Array.from(game.players[team].values())
//                 .reduce((acc, player) => {
//                     acc[player.name] = player.clicks;
//                     return acc;
//                 }, {})
//         });
//     });

//     // Game control functions
//     function startGameTimer() {
//         const game = globalState.currentGame || createNewGame();
//         game.status = 'active';
//         game.timer = 30;
        
//         // Broadcast game start
//         io.emit('gameStarted', { 
//             gameId: game.id,
//             players: game.getPlayerList()
//         });

//         game.interval = setInterval(() => {
//             game.timer--;
//             io.emit('updateTimer', game.timer);

//             if (game.timer <= 0) {
//                 endGameAndBroadcastResults();
//             }
//         }, 1000);
//     }

//     function endGameAndBroadcastResults() {
//         const game = endCurrentGame();
//         if (!game) return;

//         io.emit('gameEnded', {
//             gameId: game.id,
//             winner: game.getWinner(),
//             redCount: game.scores.red,
//             blueCount: game.scores.blue,
//             leaderboard: game.leaderboard
//         });
//     }

//     // Admin controls
//     socket.on('startGame', startGameTimer);
//     socket.on('restartGame', () => {
//         endCurrentGame();
//         startGameTimer();
//     });
//     socket.on('endGame', endGameAndBroadcastResults);

//     // Handle disconnection
//     socket.on('disconnect', () => {
//         if (globalState.currentGame && socket.playerId) {
//             globalState.currentGame.removePlayer(socket.playerId);
//             io.emit('updatePlayers', globalState.currentGame.getPlayerList());
//         }
//     });
// });

// // Error handling middleware
// app.use((err, req, res, next) => {
//     console.error(err.stack);
//     res.status(500).send('Something broke!');
// });

// // Start server
// const PORT = process.env.PORT || 3000;
// http.listen(PORT, () => {
//     console.log(`Server running on port ${PORT}`);
// });

// // Handle server shutdown
// process.on('SIGTERM', () => {
//     http.close(() => {
//         console.log('Server shutting down');
//         process.exit(0);
//     });
// });
const express = require('express');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);

app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Game state management
let gameState = {
    isActive: false,
    timer: 30,
    redCount: 0,
    blueCount: 0,
    players: {
        red: [],
        blue: []
    },
    playerClicks: {},
    interval: null
};

// Routes
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.get('/game', (req, res) => {
    res.sendFile(__dirname + '/public/game.html');
});

app.get('/admin', (req, res) => {
    res.sendFile(__dirname + '/public/admin.html');
});

// Game state management functions
function resetGameState() {
    gameState.redCount = 0;
    gameState.blueCount = 0;
    gameState.playerClicks = {};
    gameState.timer = 30;
    
    // Initialize click counts for all players
    Object.values(gameState.players).flat().forEach(name => {
        gameState.playerClicks[name] = 0;
    });
}

function clearGameInterval() {
    if (gameState.interval) {
        clearInterval(gameState.interval);
        gameState.interval = null;
    }
}

function endGameAndShowResults() {
    clearGameInterval();
    gameState.isActive = false;
    
    const leaderboard = Object.entries(gameState.playerClicks)
        .map(([name, clicks]) => ({
            name,
            clicks,
            team: [...gameState.players.red, ...gameState.players.blue].includes(name) ? 
                  (gameState.players.red.includes(name) ? 'red' : 'blue') : 'unknown'
        }))
        .sort((a, b) => b.clicks - a.clicks);

    const winner = gameState.redCount > gameState.blueCount ? 'Red' : 
                  gameState.redCount < gameState.blueCount ? 'Blue' : 'Tie';
                  
    io.emit('gameEnded', {
        winner,
        redCount: gameState.redCount,
        blueCount: gameState.blueCount,
        leaderboard
    });
}

function startGameTimer() {
    clearGameInterval();
    resetGameState();
    gameState.isActive = true;
    io.emit('gameStarted');

    gameState.interval = setInterval(() => {
        gameState.timer--;
        io.emit('updateTimer', gameState.timer);

        if (gameState.timer <= 0) {
            endGameAndShowResults();
        }
    }, 1000);
}

// Socket.IO connection handling
io.on('connection', (socket) => {
    // Handle player joining a team
    socket.on('joinTeam', (data) => {
        const { name, team } = data;
        
        // Remove player from any existing team
        gameState.players.red = gameState.players.red.filter(player => player !== name);
        gameState.players.blue = gameState.players.blue.filter(player => player !== name);
        
        // Add player to selected team
        gameState.players[team].push(name);
        gameState.playerClicks[name] = 0;
        
        // Store player info in socket
        socket.playerName = name;
        socket.team = team;
        
        // Broadcast updated player lists
        io.emit('updatePlayers', gameState.players);
    });

    // Handle block clicks
    socket.on('blockClick', (team) => {
        if (gameState.isActive && socket.team === team) {
            // Increment team score
            if (team === 'red') {
                gameState.redCount++;
            } else if (team === 'blue') {
                gameState.blueCount++;
            }
            
            // Increment player's individual score
            if (socket.playerName) {
                gameState.playerClicks[socket.playerName]++;
            }
            
            // Broadcast updated scores
            io.emit('updateCounts', {
                red: gameState.redCount,
                blue: gameState.blueCount,
                playerClicks: gameState.playerClicks
            });
        }
    });

    // Admin controls
    socket.on('startGame', () => {
        startGameTimer();
    });

    socket.on('restartGame', () => {
        startGameTimer();
    });

    socket.on('endGame', () => {
        endGameAndShowResults();
    });

    // Handle disconnection
    socket.on('disconnect', () => {
        if (socket.playerName) {
            // Remove player from their team
            gameState.players.red = gameState.players.red.filter(name => name !== socket.playerName);
            gameState.players.blue = gameState.players.blue.filter(name => name !== socket.playerName);
            
            // Remove player's click count
            delete gameState.playerClicks[socket.playerName];
            
            // Broadcast updated player lists
            io.emit('updatePlayers', gameState.players);
        }
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});

// Start server
const PORT = process.env.PORT || 3000;
http.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

// Handle server shutdown
process.on('SIGTERM', () => {
    http.close(() => {
        console.log('Server shutting down');
        process.exit(0);
    });
});